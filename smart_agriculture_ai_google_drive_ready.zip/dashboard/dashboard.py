
import streamlit as st
import pandas as pd
import numpy as np
import joblib
import plotly.express as px

from utils.irrigation_ai import irrigation_recommendation
from utils.alerts import farm_alerts
from satellite.ndvi_analysis import calculate_ndvi,crop_health

def run_dashboard():

    st.set_page_config(page_title="Smart Agriculture AI",layout="wide")

    st.sidebar.title("Smart Agriculture System")

    menu=st.sidebar.radio("Menu",[
    "Dashboard",
    "Crop Prediction",
    "Irrigation AI",
    "NDVI Health"
    ])

    model=joblib.load("models/crop_model.pkl")

    if menu=="Dashboard":

        st.title("Farm Analytics")

        df=pd.DataFrame({
        "Day":["Mon","Tue","Wed","Thu","Fri"],
        "Moisture":[30,35,40,38,36]
        })

        fig=px.line(df,x="Day",y="Moisture",title="Soil Moisture Trend")

        st.plotly_chart(fig)

    elif menu=="Crop Prediction":

        st.title("Crop Yield Prediction")

        t=st.slider("Temperature",20,40)
        h=st.slider("Humidity",30,90)
        m=st.slider("Soil Moisture",10,70)

        if st.button("Predict"):

            pred=model.predict(np.array([[t,h,m]]))
            st.success(f"Predicted Yield: {pred[0]}")

    elif menu=="Irrigation AI":

        st.title("Smart Irrigation")

        m=st.slider("Moisture",0,100,35)
        t=st.slider("Temperature",15,45,30)
        h=st.slider("Humidity",20,100,60)

        if st.button("Analyze"):

            result=irrigation_recommendation(m,t,h)
            alerts=farm_alerts(t,m)

            st.info(result)

            for a in alerts:
                st.warning(a)

    elif menu=="NDVI Health":

        st.title("NDVI Crop Health")

        nir=st.slider("NIR",0.0,1.0,0.8)
        red=st.slider("RED",0.0,1.0,0.3)

        ndvi=calculate_ndvi(nir,red)

        st.metric("NDVI",round(ndvi,2))
        st.success(crop_health(ndvi))
