
def irrigation_recommendation(moisture,temp,humidity):

    if moisture < 30:
        return "Irrigation Required"

    elif moisture < 40 and temp > 30:
        return "Moderate Irrigation"

    else:
        return "No Irrigation Needed"
