
def farm_alerts(temp,moisture):

    alerts=[]

    if temp>38:
        alerts.append("High temperature risk")

    if moisture<25:
        alerts.append("Soil too dry")

    return alerts
