
def calculate_ndvi(nir,red):
    return (nir-red)/(nir+red)

def crop_health(ndvi):

    if ndvi>0.6:
        return "Healthy crop"
    elif ndvi>0.3:
        return "Moderate growth"
    else:
        return "Poor crop health"
